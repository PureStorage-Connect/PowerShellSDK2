# Quick Start Guide for Pure Storage PowerShell SDK 2
# Step-by-step examples
# Author:
#    mnelson@purestorage.com
# Description:
#    Simple walk-though of some examples to be used with the Pure Storage PowerShell SDK 2.
#    Most of these correspond to the "How-To" articles on PowerShell available in the
#      Microsoft Platform Guide at https://support.purestorage.com/Solutions/Microsoft_Platform_Guide
#    Validated with SDK 2.2.272.0
#
# v2.2.272.0
# 2020/08/20
#
# The contents of this file are not intended to be used in any environment without testing the command first.
# This file may be updated from time to time and will be made available in this Github repository.

#
# Getting Started
#
# Basic PowerShell routines to see the cmdlets available, updating Help, and getting various degrees of Help
Get-Module -ListAvailable
$env:PSModulePath
# All of the available cmdlets in the module
Get-Command -Module PureStoragePowerShellSDK2
# How many cmdlets are available in the module
(Get-Command -Module PureStoragePowerShellSDK2).Count
# Periodically, the Help should be updated for all PowerShell modules. This does require PowerShell be "Run as Administrator".
Update-Help -Module PureStoragePowerShellSDK2
# All the variations of Help available for cmdlets
Get-Help New-Pfa2Array
Get-Help New-Pfa2Array -Full
Get-Help New-Pfa2Array -Detailed
Get-Help New-Pfa2Array -Examples

#
# Connecting to the FlashArray
#
# There are a couple of ways to connect to the FlashArray - via API Tokens or OAuth2. OAuth2 is more secure, but also a bit more complex.
# To see all of the ways to authenticate to an array with the SDK, inclusing with OAuth2, please see this article -
#   https://support.purestorage.com/Solutions/Microsoft_Platform_Guide/a_Windows_PowerShell/How-To%3A_Connect_to_FlashArray_with_SDK_v12x
#
# Note: OAuth2 is the only allowed method of authentication with Purity API versions 2.0 and 2.1.
# Note: Not all cmdlets or parameters are available with API versions 2.0 and 2.1. For information, please refer to the SDKv2 and API Version Matrix in the Github repository.
# To view all of the available API versions on your array, use this URL, substituting your array FQDN or IP address:
https://<FQDN or IP Address of Array>/api/api_version
#
# For these examples, we will do a simple API Token exchange.
$Creds = Get-Credential
# Change the <IP/FQDN> to match your array
$FlashArray = Connect-Pfa2Array -EndPoint <IP/FQDN> -Credentials $Creds -IgnoreCertificateError
# Once connected, run a few commands to verify connectivity
Get-Pfa2Controller -Array $FlashArray
$Controllers = Get-Pfa2Controller –Array $FlashArray
$Controllers

#
# Working with Volumes
#
# Create a new volume that is 200GB in size and just to see what's happening, turn on the -Verbose parameter
New-Pfa2Volume -Array $FlashArray -Name 'SDKv2-Sample' -Provisioned 214748364800 -Verbose
# Create 5 volumes, all 200GB in size
ForEach ($i in 1..5) { New-Pfa2Volume -Array $FlashArray -Name "SDKv2-TestSample-$i" -Provisioned 214748364800 }
# View the volumes after creation
Get-Pfa2Volume -Array $FlashArray -Name 'SDKv2-TestSample-3' | Format-Table –Autosize
Get-Pfa2Volume -Array $FlashArray | Where-Object { $_.name -like 'SDKv2-TestSample*' } | Format-Table -AutoSize
# Change the name of a volume
Update-Pfa2Volume -Array $FlashArray -Name 'SDKv2-TestSample-5' -VolumeName 'SDKv2-TestSample-500'
# Create a volume using the CLI via SSH
$CommandText = "purevol create --size 10G DEMO-VOL10"
Invoke-Pfa2CLICommand -EndPoint $ArrayEndpoint -Username $ArrayUsername -Password $ArrayPassword -CommandText $CommandText

#
# Volume and Host Connections
#
# Define some (fake) WWNs and create a host
$wwn=@('10:00:00:00:00:00:11:11','10:00:00:00:00:00:12:12')
New-Pfa2Host –Array $FlashArray –Name ‘SDKv2-host’ –WwnList $wwn
# Do the same for iSCSI Iqns
$iqn = @('iqn.1998-01.com.sample1.iscsi', 'iqn.1998-01.com.sample2.iscsi')
New-Pfa2Host -Array $FlashArray -Name 'SDK2-IQNS-host' -Iqns $iqn
# Create a new Host Group
New-Pfa2HostGroup -Array $FlashArray -Name 'SDKv2-HostGroup'
# Add a host to the group
New-Pfa2HostGroupHost -GroupNames 'SDKv2-HostGroup' -MemberNames 'TEST-HOST1'
# Retrieve a volume and connect it to the host & host group
Get-Pfa2Volume -Array $FlashArray | Where-Object { $_.name -like 'SDK*' } | Format-Table -AutoSize
New-Pfa2Connection -Array $FlashArray -VolumeNames 'SDKv2-Sample-2' -HostNames 'SDKv2-host'
New-Pfa2Connection -Array $FlashArray -VolumeNames 'SDKv2-Sample-2' -HostGroupNames 'SDKv2-HostGroup'
# Remove the volume from the host group
Remove-Pfa2Connection -Array $FlashArray -VolumeNames 'SDKv2-Sample-2' -HostGroupNames 'SDKv2-HostGroup'

#
# FlashRecover Snapshots
#
# Create snapshots, view them, and copy a snapshot to a new volume
New-Pfa2VolumeSnapshot -Array $FlashArray -SourceNames 'SDKv2-sample-1', 'SDKv2-sample-2' -Suffix 'EXAMPLE'
Get-Pfa2VolumeSnapshot -Name 'SDKv2-sample-1.EXAMPLE'
$src = New-Pfa2ReferenceObject -Id <returned snapshot ID> -Name <returned snapshot name>
New-Pfa2Volume -Name volumecopy -Source $src

#
# Protection Groups
#
# Create a Protection group, create a new volume, add the volume to the group, snashot it, and set the snapshot schedule for the group.
New-Pfa2ProtectionGroup -Array $FlashArray -Name 'SDKv2-PGROUP'
New-Pfa2Volume -Name 'SDKv2-VOL1' -Provisioned 10485760
New-Pfa2ProtectionGroupVolume -GroupNames 'SDKv2-PGROUP' -MemberNames 'SDKv2-VOL1'
New-Pfa2ProtectionGroupSnapshot -Array $FlashArray -SourceNames 'SDKv2-PGROUP' -Suffix 'EXAMPLE'
Get-Pfa2ProtectionGroupSnapshot -Array $FlashArray -Name 'SDKv2-PGROUP'
$schedule = Get-Pfa2ProtectionGroup -Array $FlashArray -Name 'SDKv2-PGROUP'
$schedule.SnapshotSchedule
$snapschedule=New-Pfa2SnapshotScheduleObject -At 7200000 -Enabled $false -Frequency 259200000
Update-Pfa2ProtectionGroup -Name 'SDKv2-PGROUP' -SnapshotSchedule $snapschedule
# Remove the protection group
Remove-Pfa2VolumeProtectionGroup -Array $FlashArray -MemberNames 'SDKv2-VOL1' -GroupNames 'SDKv2-PGROUP'
# Add a host to a Protection group, create a snapshot, and remove the host
New-Pfa2ProtectionGroupHost -Array $FlashArray -GroupNames 'SDKv2-PGROUP' -Membernames 'SDKv2-HOST'
New-Pfa2ProtectionGroupSnapshot -Array $FlashArray -SourceNames 'SDKv2-PGROUP'
Remove-Pfa2ProtectionGroupHost -Array $FlashArray -MemberNames 'SDKv2-HOST' -GroupNames 'SDKv2-PGROUP'
# Create a new Host Protection group and create a snapshot of the group
New-Pfa2HostGroupsProtectionGroup -Array $FlashArray -MemberNames 'SDKv2-HOSTGROUP' -GroupNames 'SDKv2-PGROUP'
New-Pfa2ProtectionGroupSnapshot -Array $FlashArray -SourceNames 'SDKv2-PGROUP'

#
# Performance and Space Metrics
#
# These are just a small sample of many performance and metric cmdlets available in the SDK.
# This example will retrieve all of the cmdlets that have Performance in the name, and then run a few Array performance commands outputting in different formats
Get-Command -Module PureStoragePowerShellSDK2 *Performance*
Get-Pfa2ArrayPerformance -Array $FlashArray -endtime '2020-08-07T01:00:00Z' -starttime '2020-08-06T01:00:00Z' -resolution 28800000
Get-Pfa2ArrayPerformance -Array $FlashArray -endtime '2020-08-07T01:00:00Z' -starttime '2020-08-06T01:00:00Z' -resolution 28800000 | Format-Table –AutoSize
Get-Pfa2ArrayPerformance -Array $FlashArray -endtime '2020-08-07T01:00:00Z' -starttime '2020-08-06T01:00:00Z' -resolution 28800000 | Export-Csv -Path ‘C:\temp\test.csv’
Get-Pfa2ArraySpace -Array $FlashArray -endtime '2020-08-07T01:00:00Z' -starttime '2020-08-06T01:00:00Z' -resolution 28800000

#
# Logging
#
# Start SDK logging to a file calles session.log in the current folder
Set-Pfa2Logging -LogFilename session.log
# You could now open a new PowerShell session and use the Get-Content cmdlet to view that file as it is written to
Get-Content session.log -Wait

#
# EOF